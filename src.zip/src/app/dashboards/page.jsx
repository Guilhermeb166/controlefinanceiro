/**
 * Página de Dashboards (Server Component).
 * Exibe análises gerais e por categoria das despesas do usuário.
 */
import CategoryAnalysis from "@/components/Dashboards/CategoryAnalysis";
import GeneralAnalysis from "@/components/Dashboards/GeneralAnalysis";

export default function DashboardPage() {
    return (
        <main className="min-h-screen max-w-[95%] m-auto p-4 flex flex-col gap-10">
            <GeneralAnalysis/>
            <CategoryAnalysis/>
        </main>
    )
}
