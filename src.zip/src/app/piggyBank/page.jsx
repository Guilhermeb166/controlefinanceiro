/*
 * Página do Cofrinho - Reserva de Emergência
 * Permite Visular, Depositar e Retirar dinheiro do cofrinho
*/

import PiggyBankMain from "@/components/PiggyBank/PiggyBankMain";

export default function PiggyBankPage() {
    return <PiggyBankMain/>
}
