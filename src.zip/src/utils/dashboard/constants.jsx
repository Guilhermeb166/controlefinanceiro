/**
 * Constantes utilizadas nos dashboards, como os nomes abreviados dos dias da semana.
 */
export const WEEK_DAYS = [
  "Seg",
  "Ter",
  "Qua",
  "Qui",
  "Sex",
  "Sáb",
  "Dom"
]
